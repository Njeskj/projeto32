For **feature requests**, you can delete this whole txt.

For **bug reports**, please use the folowing structure:

1. expected behaviour
2. incorrect behaviour
3. the operating system & version
4. PHP version on the server
5. MySQL / MariaDB version on the server
