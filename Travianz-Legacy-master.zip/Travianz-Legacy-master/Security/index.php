<?php
header('location: /');
exit;
?>