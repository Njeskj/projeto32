<?php
#################################################################################
##              -= YOU MAY NOT REMOVE OR CHANGE THIS NOTICE =-                 ##
## --------------------------------------------------------------------------- ##
##  Filename       404.tpl                                                     ##
##  Developed by:  aggenkeech                                                  ##
##  License:       TravianX Project                                            ##
##  Copyright:     TravianX (c) 2010-2012. All rights reserved.                ##
##                                                                             ##
#################################################################################
?>
<div style="margin-top: 50px;">
	<div style="text-align: center">
		<h1>404 - File not found</h1>
		<img src="../../gpack/travian_default/img/misc/404.gif" title="Not Found" alt="Not Found"><br />
		<p>We looked 404 times already but can't find anything, Not even an X marking the spot.</p>
		<p>This system is not complete yet. So the page probably does not exist.</p><br>
	</div>
</div>