<?php
#################################################################################
##              -= YOU MAY NOT REMOVE OR CHANGE THIS NOTICE =-                 ##
## --------------------------------------------------------------------------- ##
##  Filename       resetdone.tpl                                               ##
##  Developed by:  Ronix                                                       ##
##  License:       TravianZ Project                                            ##
##  Copyright:     TravianZ (c) 2012-2014. All rights reserved.                ##
##                                                                             ##
#################################################################################
unset($_SESSION['admin_username'], $_SESSION['sessid']);
?>
<table id="member">
    <thead>
        <tr>
            <th>Server Resetting</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                <br />
                <div style="text-align: center">
                	Resetting Server already done.</div>
                <br />Multihunter password is: 123456<br>&nbsp;
            </td>
        </tr>
    </tbody>
</table>
