function show_flags(){
	
}
