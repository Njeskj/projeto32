<?php

$ntype = array(1=>16,17,19,20);
echo count($ntype);

?>