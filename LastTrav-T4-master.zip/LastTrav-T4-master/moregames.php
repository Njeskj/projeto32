<h3 class="pop popgreen bold">More games</h3>
<div class="games">
	<div class="games-img" id="goalunited"></div>
	<div class="games-details">
		<h3 class="mg bold">Goalunited</h3>
		<p>In Goalunited, the award-winning football managment game, you are responsible for managing your very own football club. Train your players, manage your team list and your personnel and built your own stadium. Lead your club with tacticall finesse, a bit of luck and patiance so you can become the very best.</p>
		<div class="btn-green">
			<div class="btn-green-l"></div>
			<div class="btn-green-c">
				<a target="blank" class="npage" href="http://tracking.traviangames.com/105111103091120/12">register</a>
			</div>
			<div class="btn-green-r"></div>
		</div>
	</div>
</div>
<div class="games-divider"></div>
<div class="games">
	<div class="games-img" id="imperion"></div>
	<div class="games-details">
		<h3 class="mg bold">Imperion</h3>
        <p>Imperion is a mass multiplayer game set in a persistent future world in space; you begin the game in the year 2137 as Commander of your very own planet. You can expand your empire, research new technologies and develop powerful spaceships. Find an alliance, and colonize or conquer new planets. The universe is waiting for you...</p>
        <div class="btn-green">
            <div class="btn-green-l"></div>
            <div class="btn-green-c">
                <a target="blank" class="npage" href="http://tracking.traviangames.com/105111091791120/15">register</a>
            </div>
            <div class="btn-green-r"></div>
        </div>
    </div>
</div>
<div class="games-divider"></div>
<div class="games">
    <div class="games-img" id="travian"></div>
    <div class="games-details">
        <h3 class="mg bold">TRAVIAN</h3>
        <p>TRAVIAN is the award-winning browsergame set in a persistent ancient world. Begin the game as the leader of a small village; from there, you can grow and expand, wage wars or conduct peaceful trades with your neighbours. Fight your way to the very top with the help of your allies and confederacies, and become the most powerful empire in the game.</p>
        <div class="btn-green">
            <div class="btn-green-l"></div>
            <div class="btn-green-c">
                <a target="blank" class="npage" href="http://www.travian.com/#serverRegister">register</a>
            </div>
            <div class="btn-green-r"></div>
        </div>
    </div>
</div>
<div class="games-divider"></div>
<div class="games">
    <div class="games-img" id="travians"></div>
    <div class="games-details">
        <h3 class="mg bold">Travians</h3>
        <p>The role play game (= RPG) Travians allows you to experience a completely new set of adventures. You can complete missions, learn a profession and join a guild! Prove your might by fighting in the arena and develop your character further. Become a part of the quickly growing MMORPG community now and make new friends in the world of Travians!</p>
        <div class="btn-green">
            <div class="btn-green-l"></div>
            <div class="btn-green-c">
                <a target="blank" class="npage" href="http://tracking.traviangames.com/105111084902120/2">register</a>
            </div>
            <div class="btn-green-r"></div>
        </div>
    </div>
</div>
<div class="games-divider"></div>
<div class="games">
    <div class="games-img" id="wewaii"></div>
    <div class="games-details">
        <h3 class="mg bold">Wewaii</h3>
        <p>In Wewaii, the twice awarded online game, you can plan, build and manage your very own hotel. You can optimize your offer and attract guests straight from the airport. With a bit of luck, you can make the holiday dream come true.</p>
        <div class="btn-green">
            <div class="btn-green-l"></div>
            <div class="btn-green-c">
                <a target="blank" class="npage" href="http://tracking.traviangames.com/105111093891120/9">register</a>
            </div>
            <div class="btn-green-r"></div>
        </div>
    </div>
</div>